"""Full-model HF eager checkpoint roundtrip; separate from native serving timings."""
import copy
import hashlib
import io
import json
import os
import pathlib
import random
import time

import torch
import torch_npu
from transformers import Qwen3_5ForConditionalGeneration

ROOT = pathlib.Path('/workspace/cjw-research')
OUT = ROOT / 'results/hybrid_state_roundtrip.json'


def main():
    assert os.environ['ASCEND_RT_VISIBLE_DEVICES'] == '7'
    torch.npu.set_device(0)
    torch.npu.config.allow_internal_format = False
    report = {'complete': False, 'node': '203', 'physical_card': 7, 'seed': 20261009,
              'source_sha256': hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),
              'gates': 'Every restored tensor exact; eight greedy IDs exact; per-step full-logit relative RMSE <= 1e-6',
              'limits': 'Full-model HF eager, not native SGLang; synthetic prefix256/suffix64; same-device CPU serialization roundtrip, no network or serving gain'}
    OUT.write_text(json.dumps(report, indent=2))
    try:
        with torch.inference_mode():
            model = Qwen3_5ForConditionalGeneration.from_pretrained(
                ROOT / 'models/Qwen3.5-0.8B', dtype=torch.bfloat16,
                attn_implementation='eager', local_files_only=True).eval().to('npu')
            rng = random.Random(20261009)
            prefix = torch.tensor([[rng.randrange(1000, 12000) for _ in range(256)]], device='npu')
            suffix = torch.tensor([[rng.randrange(12000, 24000) for _ in range(64)]], device='npu')
            start = time.perf_counter()
            initial = model(input_ids=prefix, use_cache=True, logits_to_keep=1)
            torch.npu.synchronize()
            report['cold_prefix_s'] = time.perf_counter() - start
            cache = initial.past_key_values
            # Enumerate every tensor field, preserving all non-tensor layer/cache metadata.
            fields = [(i, name, value) for i, layer in enumerate(cache.layers)
                      for name, value in vars(layer).items() if isinstance(value, torch.Tensor)]
            assert fields and any(n == 'recurrent_states' for _, n, _ in fields)
            assert any(n == 'keys' for _, n, _ in fields)
            report['tensors'] = [{'layer': i, 'name': n, 'shape': list(v.shape), 'dtype': str(v.dtype),
                                  'bytes': v.numel()*v.element_size()} for i, n, v in fields]
            report['tensor_bytes'] = sum(x['bytes'] for x in report['tensors'])
            start = time.perf_counter()
            host_cache = copy.deepcopy(cache)
            for i, name, value in fields:
                setattr(host_cache.layers[i], name, value.cpu())
            torch.npu.synchronize()
            report['snapshot_to_cpu_s'] = time.perf_counter() - start
            buffer = io.BytesIO()
            start = time.perf_counter()
            torch.save(host_cache, buffer)
            report['serialize_s'] = time.perf_counter() - start
            report['serialized_bytes'] = len(buffer.getbuffer())
            report['serialized_sha256'] = hashlib.sha256(buffer.getbuffer()).hexdigest()
            # This artifact is created by us in this process; no untrusted pickle is loaded.
            start = time.perf_counter()
            restored = torch.load(io.BytesIO(buffer.getvalue()), weights_only=False, map_location='cpu')
            for i, name, value in fields:
                setattr(restored.layers[i], name, getattr(restored.layers[i], name).to('npu'))
            torch.npu.synchronize()
            report['deserialize_and_h2d_s'] = time.perf_counter() - start
            report['all_tensors_exact'] = all(torch.equal(v, getattr(restored.layers[i], n)) for i,n,v in fields)
            assert report['all_tensors_exact']

            def continuation(state):
                outputs, logits = [], []
                result = model(input_ids=suffix, past_key_values=state, use_cache=True, logits_to_keep=1)
                for step in range(8):
                    current = result.logits[:, -1].float().clone()
                    token = current.argmax(-1).reshape(1, 1)
                    outputs.append(token.item())
                    logits.append(current.cpu())
                    if step < 7:
                        result = model(input_ids=token, past_key_values=result.past_key_values,
                                       use_cache=True, logits_to_keep=1)
                torch.npu.synchronize()
                return outputs, logits

            reference_ids, reference = continuation(cache)
            restored_ids, actual = continuation(restored)
            report['reference_ids'] = reference_ids
            report['restored_ids'] = restored_ids
            report['greedy_ids_exact'] = reference_ids == restored_ids
            report['relative_rmse_by_step'] = [((a-b).square().mean()/b.square().mean()).sqrt().item()
                                               for a,b in zip(actual, reference)]
            report['all_gates_passed'] = report['greedy_ids_exact'] and max(report['relative_rmse_by_step']) <= 1e-6
            assert report['all_gates_passed']
            report['complete'] = True
    except Exception as exc:
        report['error'] = repr(exc)
        raise
    finally:
        OUT.write_text(json.dumps(report, indent=2))
        print(json.dumps(report), flush=True)


if __name__ == '__main__':
    main()

"""Feasibility screen for collective engine choices under compute overlap.

Synthetic NPU graphs only. One HCCL communicator per process; different engine
modes are tested in separate launches, never with concurrent communicators.
"""
import argparse
import datetime
import hashlib
import json
import os
import pathlib
import random
import time

import torch
import torch.distributed as dist
import torch_npu


def main(a):
    rank = int(os.environ['RANK'])
    torch.set_num_threads(2)
    torch.npu.set_device(int(os.environ['LOCAL_RANK']))
    torch.npu.config.allow_internal_format = False
    root = pathlib.Path('/workspace/cjw-research/results')
    report = {'complete': False, 'arguments': vars(a), 'rank': rank,
              'physical_cards': [6,7], 'torch': torch.__version__, 'torch_npu': torch_npu.__version__,
              'source_sha256': hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),
              'scope': 'Same-node synthetic BF16 AllReduce and compute graphs; not an LLM serving experiment',
              'gates': 'AllReduce full payload exactly3; Cube output exactly2048; vector softmax exactly1/4096',
              'cases': []}
    tag = f'_{a.tag}' if a.tag else ''
    target = root / f'comm_engine_mode{a.mode}{tag}_rank{rank}.json'
    target.write_text(json.dumps(report, indent=2))
    initialized = False
    control = None
    try:
        opts = torch_npu._C._distributed_c10d.ProcessGroupHCCL.Options()
        opts.hccl_config = {'hccl_op_expansion_mode': a.mode}
        dist.init_process_group('hccl', pg_options=opts, timeout=datetime.timedelta(seconds=120))
        initialized = True
        control = dist.new_group(backend='gloo', timeout=datetime.timedelta(seconds=120))
        compute_stream, comm_stream = torch.npu.Stream(), torch.npu.Stream()
        cube_input = torch.ones((2048,2048), dtype=torch.bfloat16, device='npu')
        cube_out = torch.empty_like(cube_input)
        vector_input = torch.ones((1024,4096), dtype=torch.bfloat16, device='npu')
        vector_out = torch.empty_like(vector_input)
        graphs = {}
        for name in ('cube','vector'):
            def compute():
                for _ in range(16):
                    if name == 'cube':
                        torch.mm(cube_input, cube_input, out=cube_out)
                    else:
                        torch.softmax(vector_input, dim=-1, out=vector_out)
            with torch.npu.stream(compute_stream):
                for _ in range(3):
                    compute()
            compute_stream.synchronize()
            graph = torch.npu.NPUGraph()
            with torch.npu.graph(graph, stream=compute_stream):
                compute()
            graphs[name] = graph
        torch.npu.synchronize()
        assert cube_out.eq(2048).all().item()
        assert vector_out.eq(1/4096).all().item()
        rng = random.Random(20261009)
        communication_graphs = []
        for kib in (32,256,2048):
            source = torch.full((kib*1024//2,), rank+1, dtype=torch.bfloat16, device='npu')
            output = torch.empty_like(source)
            with torch.npu.stream(comm_stream):
                for _ in range(5):
                    output.copy_(source)
                    dist.all_reduce(output)
            comm_stream.synchronize()
            graph = torch.npu.NPUGraph()
            with torch.npu.graph(graph, stream=comm_stream):
                output.copy_(source)
                dist.all_reduce(output)
            # Keep all captured pointer registrations alive across every shape.
            communication_graphs.append((source, output, graph))
            graph.replay()
            torch.npu.synchronize()
            assert output.eq(3).all().item()
            # Warm every combined shape before the randomized recorded order.
            for name in ('none','cube','vector'):
                for _ in range(3):
                    if name != 'none':
                        with torch.npu.stream(compute_stream):
                            graphs[name].replay()
                    with torch.npu.stream(comm_stream):
                        graph.replay()
                    torch.npu.synchronize()
            order = [(r,n) for r in range(a.repeats) for n in ('none','cube','vector')]
            rng.shuffle(order)
            for repeat,name in order:
                dist.barrier(group=control)
                start = time.perf_counter()
                if name != 'none':
                    with torch.npu.stream(compute_stream):
                        graphs[name].replay()
                with torch.npu.stream(comm_stream):
                    graph.replay()
                comm_stream.synchronize()
                comm_end = time.perf_counter()
                compute_stream.synchronize()
                elapsed = time.perf_counter()-start
                exact = output.eq(3).all().item()
                if not exact:
                    report['failure'] = {'kib':kib,'repeat':repeat,'compute':name,
                                         'bad_elements':int(output.ne(3).sum().item()),
                                         'minimum':float(output.min().item()),'maximum':float(output.max().item())}
                    raise RuntimeError('AllReduce payload gate failed')
                if name == 'cube':
                    assert cube_out.eq(2048).all().item()
                if name == 'vector':
                    assert vector_out.eq(1/4096).all().item()
                case = {'kib':kib, 'repeat':repeat, 'compute':name,
                        'comm_completion_ms':1000*(comm_end-start), 'whole_ms':1000*elapsed,
                        'full_payload_exact':True}
                report['cases'].append(case)
                print(json.dumps(case),flush=True)
                target.write_text(json.dumps(report,indent=2))
            # Keep source/output alive until all replays of their graph finish.
            torch.npu.synchronize()
        report['complete'] = True
    except Exception as exc:
        report['error'] = repr(exc)
        raise
    finally:
        if control is not None:
            dist.destroy_process_group(control)
        if initialized:
            dist.destroy_process_group()
        target.write_text(json.dumps(report,indent=2))


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--mode',type=int,choices=(0,1,4),required=True)
    p.add_argument('--repeats',type=int,default=5)
    p.add_argument('--tag',default='')
    main(p.parse_args())

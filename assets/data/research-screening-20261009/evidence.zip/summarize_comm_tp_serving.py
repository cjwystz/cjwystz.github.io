"""Independent fixed-mode full-model gates; no dynamic serving gain claim."""
import csv
import bisect
import hashlib
import json
import pathlib
import statistics
from decimal import Decimal

ROOT = pathlib.Path(__file__).resolve().parent
RESULTS = ROOT / 'results'


def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def metrics(case):
    requests = case['run']['requests']
    samples = []
    for r in requests:
        deltas = [1000 * (b['time_s'] - a['time_s']) for a, b in zip(r['events'], r['events'][1:])
                  if b['tokens'] - a['tokens'] == 1 and 64 < b['tokens'] <= 192]
        if r['meta_info']['completion_tokens'] == 256:
            assert len(deltas) >= 100, 'Insufficient unit-token samples'
            samples.append(statistics.mean(deltas))
    return {'whole_ms': case['run']['elapsed_s'] * 1000,
            'mean_request_ttft_ms': statistics.mean(r['ttft_s'] * 1000 for r in requests),
            'central_itl_ms': statistics.mean(samples) if samples else None,
            'central_samples_per_request': [len([1 for a, b in zip(r['events'], r['events'][1:])
                if b['tokens'] - a['tokens'] == 1 and 64 < b['tokens'] <= 192]) for r in requests] if samples else []}


def profile(path):
    rows = list(csv.DictReader(path.open()))
    comms = [r for r in rows if r['Name'].startswith('hcom_')]
    cubes = [r for r in rows if 'matmul' in r['Name'].lower() or 'addmm' in r['Name'].lower() or 'aclnnmm_' in r['Name'].lower()]
    assert comms and cubes, 'Missing expected model device events'
    kernels = []
    for r in cubes:
        start = Decimal(r['Start Time(us)'].strip())
        kernels.append((start, start + Decimal(r['Duration(us)'])))
    kernels.sort()
    starts = [a for a, b in kernels]
    prefix_ends = []
    for a, b in kernels:
        prefix_ends.append(max(b, prefix_ends[-1]) if prefix_ends else b)
    overlaps = []
    # Logical collective spans may contain waiting. Avoid treating their nested
    # implementation kernels as independent model computation.
    for r in comms:
        start = Decimal(r['Start Time(us)'].strip())
        end = start + Decimal(r['Duration(us)'])
        lo = bisect.bisect_right(prefix_ends, start)
        hi = bisect.bisect_left(starts, end)
        overlap = sum(max(Decimal(0), min(end, b) - max(start, a)) for a, b in kernels[lo:hi])
        overlaps.append(float(overlap))
    return {'file': str(path.relative_to(RESULTS)), 'sha256': digest(path),
            'logical_collective_count': len(comms), 'aiv_kernel_count': sum(r['Name'] == 'AivKernel' for r in rows),
            'matmul_kernel_count': len(kernels),
            'collectives_with_matmul_overlap_gt1us': sum(x > 1 for x in overlaps),
            'sum_matmul_collective_overlap_us': sum(overlaps),
            'logical_collective_span_sum_us': sum(float(r['Duration(us)']) for r in comms),
            'observed_collective_shapes': sorted(set((r.get('Input Shapes', ''), r.get('Input Data Types', '')) for r in comms))}


def main():
    expected = [(0, 'first'), (4, 'first'), (0, 'confirm')]
    summary = {'all_serving_gates_passed': False, 'runs': [], 'comparison': {},
               'limits': ['Three separate server launches are not adjacent per-case pairs or a confidence interval.',
                          'Synthetic prompts, fixed shapes, same-node TP2 only; no task-quality/cross-node/controller/SLO goodput result.',
                          'Each batch is a trial; individual requests/ranks are not independent repetitions.',
                          'Central ITL uses only unit-token deltas in output window 65–192.',
                          'Profiled samples are separate; device interval intersection does not establish resource causality.']}
    ds = []
    for mode, tag in expected:
        path = RESULTS / f'comm_tp_mode{mode}_{tag}.json'
        d = json.loads(path.read_text())
        assert d['source_sha256'] == digest((RESULTS / 'comm_tp_serving_initial_source.py') if mode == 0 and tag == 'first' else (ROOT / 'comm_tp_serving_probe.py'))
        assert d['hook_sha256'] == digest(ROOT / 'comm_tp_sitecustomize.py')
        entry = {'mode': mode, 'tag': tag, 'source': path.name, 'complete': d['complete'], 'error': d.get('error')}
        summary['runs'].append(entry)
        if not d['complete']:
            summary['decision'] = 'Stopped at incomplete or failed serving gate; no performance result promoted.'
            (RESULTS / 'comm_tp_serving_summary.json').write_text(json.dumps(summary, indent=2) + '\n')
            print(json.dumps(entry))
            return
        assert len(d['timed']) == 15 and len(d['smokes']) == 3 and len(d['profiled']) == (0 if tag == 'confirm' else 3)
        if ds:
            assert d['workloads'] == ds[0]['workloads']
            assert all(d['reference_smoke_ids_equal'])
        for group in ['warmups', 'smokes', 'timed', 'profiled']:
            for c in d[group]:
                w = d['workloads'][c['workload']]
                assert len(c['run']['requests']) == w['batch_size']
                target = 32 if group == 'smokes' else (64 if c['workload'] < 2 else 32) if group == 'profiled' else w['output_tokens']
                for r in c['run']['requests']:
                    assert r['meta_info']['prompt_tokens'] == w['input_tokens']
                    assert r['meta_info']['completion_tokens'] == target
        entry['workloads'] = {}
        for i, w in enumerate(d['workloads']):
            cases = [c for c in d['timed'] if c['workload'] == i]
            assert len(cases) == 5 and {c['repeat'] for c in cases} == set(range(5))
            reference_text = [r['text'] for r in (ds[0] if ds else d)['timed'][next(j for j, c in enumerate((ds[0] if ds else d)['timed']) if c['workload'] == i)]['run']['requests']]
            text_matches = [[r['text'] for r in c['run']['requests']] == reference_text for c in cases]
            values = [metrics(c) for c in cases]
            entry['workloads'][str(i)] = {'batch_size': w['batch_size'], 'input_tokens': w['input_tokens'],
                'output_tokens': w['output_tokens'], 'trials': values,
                'full_timed_text_gate_passed': all(text_matches), 'full_timed_text_matches': text_matches,
                'mean_whole_ms': statistics.mean(v['whole_ms'] for v in values),
                'mean_ttft_ms': statistics.mean(v['mean_request_ttft_ms'] for v in values),
                'mean_central_itl_ms': statistics.mean(v['central_itl_ms'] for v in values) if values[0]['central_itl_ms'] is not None else None}
        entry['device_profiles'] = []
        for i in ([] if tag == 'confirm' else [0, 1, 2]):
            paths = sorted((RESULTS / f'comm_tp_mode{mode}_{tag}_profile{i}').rglob('kernel_details.csv'))
            assert len(paths) == 2
            entry['device_profiles'].append({'workload': i, 'ranks': [profile(p) for p in paths]})
        ds.append(d)
    for i in [0, 1, 2]:
        ws = [r['workloads'][str(i)] for r in summary['runs']]
        comparison = {}
        if not all(w['full_timed_text_gate_passed'] for w in ws):
            summary['comparison'][str(i)] = {'eligible_for_performance_conclusion': False,
                'reason': 'Full timed output-text gate failed, including within the default baseline.',
                'text_gates_by_launch': [w['full_timed_text_gate_passed'] for w in ws]}
            continue
        comparison['eligible_for_performance_conclusion'] = True
        for key in ['mean_whole_ms', 'mean_ttft_ms', 'mean_central_itl_ms']:
            if ws[0][key] is None:
                continue
            comparison[key] = {'default_first': ws[0][key], 'forced_aiv': ws[1][key], 'default_confirm': ws[2][key],
                'aiv_vs_first_percent': 100 * (ws[1][key] / ws[0][key] - 1),
                'aiv_vs_confirm_percent': 100 * (ws[1][key] / ws[2][key] - 1),
                'default_drift_percent': 100 * (ws[2][key] / ws[0][key] - 1)}
        summary['comparison'][str(i)] = comparison
    summary['all_serving_gates_passed'] = all(v['eligible_for_performance_conclusion'] for v in summary['comparison'].values())
    summary['decision'] = 'No dynamic-controller gain or novelty established. Failed-text workloads excluded; passed workloads are limited fixed-mode diagnostics with launch drift controls.'
    (RESULTS / 'comm_tp_serving_summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary['comparison'], indent=2))


if __name__ == '__main__':
    main()

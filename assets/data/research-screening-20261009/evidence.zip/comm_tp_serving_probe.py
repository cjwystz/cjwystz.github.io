"""Owned full Qwen3-8B TP2 baseline, strict greedy gates and short device profiles."""
import argparse
import concurrent.futures
import hashlib
import json
import os
import pathlib
import random
import signal
import socket
import subprocess
import time
import urllib.request

ROOT = pathlib.Path('/workspace/cjw-research')
URL = 'http://127.0.0.1:32462'


def http(path, payload=None):
    data = None if payload is None else json.dumps(payload).encode()
    return urllib.request.urlopen(urllib.request.Request(URL + path, data=data,
        headers={'Content-Type': 'application/json'}), timeout=180)


def generate(ids, count, logprob=False):
    payload = {'input_ids': ids, 'sampling_params': {'temperature': 0, 'max_new_tokens': count, 'ignore_eos': True},
               'stream': True, 'return_logprob': logprob}
    if logprob:
        payload['logprob_start_len'] = len(ids) - 1
    start = time.perf_counter()
    events = []
    final = None
    with http('/generate', payload) as response:
        for line in response:
            if line.startswith(b'data:') and line.strip() != b'data: [DONE]':
                final = json.loads(line[5:])
                if 'error' in final:
                    raise RuntimeError(final['error'])
                n = final.get('meta_info', {}).get('completion_tokens', 0)
                if n and (not events or n > events[-1]['tokens']):
                    events.append({'tokens': n, 'time_s': time.perf_counter() - start})
    meta = final['meta_info']
    assert meta['prompt_tokens'] == len(ids) and meta['completion_tokens'] == count
    result = {'ttft_s': events[0]['time_s'], 'elapsed_s': time.perf_counter() - start,
              'events': events, 'text': final['text'], 'meta_info': meta}
    if logprob:
        result['output_ids'] = [x[1] for x in meta['output_token_logprobs']]
        assert len(result['output_ids']) == count
    return result


def batch(prompts, count, logprob=False):
    start = time.perf_counter()
    with concurrent.futures.ThreadPoolExecutor(max_workers=len(prompts)) as executor:
        outputs = list(executor.map(lambda ids: generate(ids, count, logprob), prompts))
    return {'elapsed_s': time.perf_counter() - start, 'requests': outputs}


def main(a):
    assert os.environ['ASCEND_RT_VISIBLE_DEVICES'] == '6,7'
    stem = f'comm_tp_mode{a.mode}_{a.tag}'
    out = ROOT / f'results/{stem}.json'
    server_log = ROOT / f'results/{stem}_server.log'
    assert not out.exists() and not server_log.exists(), 'Preserve prior results'
    with socket.socket() as sock:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind(('127.0.0.1', 32462))
    hook = ROOT / 'comm_tp_hook/sitecustomize.py'
    assert hook.exists()
    command = ['python', '-m', 'sglang.launch_server', '--model-path', str(ROOT / 'models/Qwen3-8B'),
               '--device', 'npu', '--attention-backend', 'ascend', '--host', '127.0.0.1', '--port', '32462',
               '--tp-size', '2', '--page-size', '128', '--max-total-tokens', '16384',
               '--max-running-requests', '8', '--context-length', '8192', '--mem-fraction-static', '0.5',
               '--chunked-prefill-size', '2048', '--cuda-graph-max-bs-decode', '8', '--disable-radix-cache',
               '--random-seed', '20261009', '--decode-log-interval', '20']
    env = os.environ.copy()
    env['CJW_TP_HCCL_MODE'] = str(a.mode)
    env['PYTHONPATH'] = str(hook.parent) + (':' + env['PYTHONPATH'] if env.get('PYTHONPATH') else '')
    report = {'complete': False, 'arguments': vars(a), 'node': 203, 'physical_cards': [6, 7],
              'command': command, 'started_unix_s': time.time(),
              'source_sha256': hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),
              'hook_sha256': hashlib.sha256(hook.read_bytes()).hexdigest(),
              'scope': 'Same-node full Qwen3-8B TP2 fixed-mode serving; not dynamic-controller or cross-node TP',
              'warmups': [], 'smokes': [], 'timed': [], 'profiled': []}
    rng = random.Random(20261009)
    workloads = []
    for size, length, outputs in [(1, 512, 256), (8, 1024, 256), (1, 4096, 32)]:
        prompts = [[rng.randrange(1000, 24000) for _ in range(length)] for _ in range(size)]
        workloads.append({'batch_size': size, 'input_tokens': length, 'output_tokens': outputs, 'prompts': prompts})
    report['workloads'] = workloads
    out.write_text(json.dumps(report, indent=2))
    log = server_log.open('w')
    proc = subprocess.Popen(command, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    report['server_pid_in_container'] = proc.pid
    try:
        deadline = time.monotonic() + 300
        while True:
            if proc.poll() is not None:
                raise RuntimeError(f'server exited {proc.returncode}')
            try:
                with http('/health') as response:
                    if response.status == 200:
                        break
            except Exception:
                pass
            if time.monotonic() > deadline:
                raise TimeoutError('server readiness')
            time.sleep(.5)
        report['server_info'] = json.load(http('/get_server_info'))
        for i, w in enumerate(workloads):
            for rep in range(3):
                report['warmups'].append({'workload': i, 'repeat': rep, 'run': batch(w['prompts'], w['output_tokens'])})
            report['smokes'].append({'workload': i, 'run': batch(w['prompts'], 32, True)})
            out.write_text(json.dumps(report, indent=2))
        if a.reference:
            reference = json.loads(pathlib.Path(a.reference).read_text())
            assert reference['complete'] and reference['workloads'] == workloads
            report['reference_smoke_ids_equal'] = [
                [x['output_ids'] for x in s['run']['requests']] ==
                [x['output_ids'] for x in reference['smokes'][i]['run']['requests']]
                for i, s in enumerate(report['smokes'])]
            assert all(report['reference_smoke_ids_equal']), 'Greedy smoke IDs changed'
        order = [(rep, i) for rep in range(5) for i in range(len(workloads))]
        rng.shuffle(order)
        for rep, i in order:
            w = workloads[i]
            report['timed'].append({'workload': i, 'repeat': rep, 'run': batch(w['prompts'], w['output_tokens'])})
            out.write_text(json.dumps(report, indent=2))
        # Profile only after all unprofiled measurements are done.
        for i in ([] if a.skip_profile else [0, 1, 2]):
            profile_dir = ROOT / f'results/{stem}_profile{i}'
            with http('/start_profile', {'output_dir': str(profile_dir), 'activities': ['CPU', 'GPU'],
                                        'with_stack': False, 'record_shapes': True}) as response:
                started = response.read().decode()
            w = workloads[i]
            run = batch(w['prompts'], 64 if i < 2 else 32)
            with http('/stop_profile', {}) as response:
                stopped = response.read().decode()
            report['profiled'].append({'workload': i, 'start_response': started, 'stop_response': stopped,
                'run': run, 'profile_files': sorted(str(p.relative_to(ROOT / 'results')) for p in profile_dir.rglob('*') if p.is_file())})
            out.write_text(json.dumps(report, indent=2))
        report['complete'] = True
    except Exception as exc:
        report['error'] = repr(exc)
        raise
    finally:
        if proc.poll() is None:
            os.killpg(proc.pid, signal.SIGTERM)
            try:
                proc.wait(timeout=20)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid, signal.SIGKILL)
                proc.wait(timeout=10)
        log.close()
        report['server_returncode'] = proc.returncode
        report['finished_unix_s'] = time.time()
        out.write_text(json.dumps(report, indent=2))


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--mode', type=int, choices=(0, 4), required=True)
    p.add_argument('--tag', required=True)
    p.add_argument('--reference')
    p.add_argument('--skip-profile', action='store_true')
    main(p.parse_args())

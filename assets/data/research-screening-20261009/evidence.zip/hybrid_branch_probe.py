"""Check whether native hybrid caching learns reusable branch checkpoints."""
import argparse
import hashlib
import json
import os
import pathlib
import random
import signal
import socket
import subprocess
import time

from hybrid_prefix_readiness import COMMAND, ROOT, generate, http


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--repeats',type=int,default=1)
    parser.add_argument('--stem',default='hybrid_branch')
    args=parser.parse_args()
    assert os.environ['ASCEND_RT_VISIBLE_DEVICES'] == '6'
    report = {'complete':False, 'command':COMMAND, 'node':203, 'physical_card':6, 'seed':20261009,
              'source_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),
              'helper_sha256':hashlib.sha256((ROOT/'hybrid_prefix_readiness.py').read_bytes()).hexdigest(),
              'limits':'One synthetic branch trace; logprobs enabled; checks native baseline adaptation, not controller benefit'}
    out=ROOT/f'results/{args.stem}_probe.json'
    with socket.socket() as s:
        s.bind(('127.0.0.1',32455))
    log=(ROOT/f'results/{args.stem}_server.log').open('w')
    proc=subprocess.Popen(COMMAND,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    try:
        deadline=time.monotonic()+300
        while True:
            if proc.poll() is not None:
                raise RuntimeError(f'server exited {proc.returncode}')
            try:
                with http('/health') as response:
                    if response.status == 200:
                        break
            except Exception:
                pass
            if time.monotonic()>deadline:
                raise TimeoutError('server readiness')
            time.sleep(.5)
        rng=random.Random(20261009)
        prefix=[rng.randrange(1000,12000) for _ in range(1024)]
        templates=[{'overlap':n,'input_ids':prefix[:n]+[rng.randrange(12000,24000) for _ in range(128)]}
                 for n in (512,512,768,768)]
        queries=[]
        report['queries']=queries
        report['warmup']=[generate(prefix,32) for _ in range(2)]
        report['producers']=[]
        for repeat in range(args.repeats):
            batch=[{'repeat':repeat, **template} for template in templates]
            queries.extend(batch)
            for q in batch:
                with http('/flush_cache') as response:
                    response.read()
                q['cold_reference']=generate(q['input_ids'],32)
            with http('/flush_cache') as response:
                response.read()
            report['producers'].append(generate(prefix,1))
            for q in batch:
                q['trace_run']=generate(q['input_ids'],32)
                q['output_ids_equal']=q['trace_run']['output_ids'] == q['cold_reference']['output_ids']
                print(json.dumps({'repeat':repeat,'overlap':q['overlap'],'cached_tokens':q['trace_run']['meta_info'].get('cached_tokens'),
                                  'ids_equal':q['output_ids_equal']}),flush=True)
                out.write_text(json.dumps(report,indent=2))
        report['all_output_ids_equal']=all(q['output_ids_equal'] for q in queries)
        report['complete']=True
    except Exception as exc:
        report['error']=repr(exc)
        raise
    finally:
        if proc.poll() is None:
            os.killpg(proc.pid,signal.SIGTERM)
            try:
                proc.wait(timeout=20)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid,signal.SIGKILL)
                proc.wait(timeout=10)
        log.close()
        report['server_returncode']=proc.returncode
        out.write_text(json.dumps(report,indent=2))


if __name__ == '__main__':
    main()

"""Recompute timing and text gates only. No device-profile audit."""
import hashlib
import json
from pathlib import Path
import statistics
import summarize_comm_tp_serving as helpers

root = Path(__file__).resolve().parent
summary = json.loads((root / 'results/comm_tp_serving_summary.json').read_text())
reference = {}
for run in summary['runs']:
    raw = json.loads((root / 'results' / run['source']).read_text())
    source = root / 'results/comm_tp_serving_initial_source.py' if run['mode'] == 0 and run['tag'] == 'first' else root / 'comm_tp_serving_probe.py'
    assert raw['source_sha256'] == hashlib.sha256(source.read_bytes()).hexdigest()
    assert raw['hook_sha256'] == hashlib.sha256((root / 'comm_tp_sitecustomize.py').read_bytes()).hexdigest()
    assert raw['complete'] and len(raw['timed']) == 15
    for workload in range(3):
        cases = [c for c in raw['timed'] if c['workload'] == workload]
        texts = [[r['text'] for r in c['run']['requests']] for c in cases]
        reference.setdefault(workload, texts[0])
        gate = all(t == reference[workload] for t in texts)
        expected = run['workloads'][str(workload)]
        assert gate == expected['full_timed_text_gate_passed']
        values = [helpers.metrics(c) for c in cases]
        for key, target in [('whole_ms', 'mean_whole_ms'), ('mean_request_ttft_ms', 'mean_ttft_ms'), ('central_itl_ms', 'mean_central_itl_ms')]:
            if values[0][key] is not None:
                assert abs(statistics.mean(v[key] for v in values) - expected[target]) < 1e-8
        print(run['mode'], run['tag'], workload, 'full_timed_text_gate', gate)
print('Timing and text gate summaries verified; device profiles not audited by this script.')

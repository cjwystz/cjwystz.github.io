"""Audit strict payload gates and aggregate two-rank joint trials.

Modes run in separate launches. Differences are exploratory, not causal gains.
"""
import hashlib
import json
import pathlib
import statistics

ROOT = pathlib.Path(__file__).resolve().parent
RESULTS = ROOT / 'results'


def main():
    summary = {'scope': 'Same-node synthetic coexecution only', 'runs': {},
               'comparison': {}, 'failures_preserved': [],
               'limits': ['Separate mode launches may drift; five initial/ten confirmation joint trials are not independent rank trials.',
                          'Host completion timing includes submission; no device trace or causal resource attribution.',
                          'Requested communicator mode is recorded; actual kernel path has not been profiled.',
                          'No full LLM, cross-node TP or serving goodput measurement.']}
    for tag, sizes, source in [('lifetime', [32, 256, 2048], 'comm_engine_lifetime_source.py'),
                                ('large', [16384, 32768], 'comm_engine_large_source.py'),
                                ('confirm', [16384, 32768], '../comm_engine_probe.py')]:
        repeats = 10 if tag == 'confirm' else 5
        digest = hashlib.sha256((RESULTS / source).read_bytes()).hexdigest()
        for mode in [0, 4]:
            names = [f'comm_engine_mode{mode}_{tag}_rank{rank}.json' for rank in [0, 1]]
            ds = [json.loads((RESULTS / name).read_text()) for name in names]
            for rank, d in enumerate(ds):
                assert d['rank'] == rank and d['complete'] and not d.get('error')
                assert d['arguments']['mode'] == mode and d['arguments']['repeats'] == repeats
                assert d['source_sha256'] == digest
                assert len(d['cases']) == len(sizes) * repeats * 3
                assert all(c['full_payload_exact'] for c in d['cases'])
                if tag == 'confirm':
                    assert all(c['expected_payload'] == 3 + 2 * c['repeat'] for c in d['cases'])
            expected = {(kib, rep, compute) for kib in sizes for rep in range(repeats)
                        for compute in ['none', 'cube', 'vector']}
            key = lambda c: (c['kib'], c['repeat'], c['compute'])
            maps = [{key(c): c for c in d['cases']} for d in ds]
            assert all(set(m) == expected for m in maps)
            aggregates = {}
            for kib in sizes:
                for compute in ['none', 'cube', 'vector']:
                    values = [max(m[(kib, rep, compute)]['whole_ms'] for m in maps) for rep in range(repeats)]
                    aggregates[f'{kib}:{compute}'] = {'joint_trials': repeats,
                        'max_rank_whole_ms': values, 'median_ms': statistics.median(values),
                        'range_ms': [min(values), max(values)]}
            summary['runs'][f'mode{mode}_{tag}'] = {'files': names, 'source_sha256': digest,
                'cases_per_rank': len(expected), 'all_recorded_gates_passed': True, 'aggregates': aggregates}
        for kib in sizes:
            for compute in ['none', 'cube', 'vector']:
                entry = f'{kib}:{compute}'
                medians = {str(mode): summary['runs'][f'mode{mode}_{tag}']['aggregates'][entry]['median_ms'] for mode in [0, 4]}
                summary['comparison'][f'{tag}:{entry}'] = {'median_ms': medians,
                    'mode4_vs_mode0_percent': 100 * (medians['4'] / medians['0'] - 1)}
    for rank in [0, 1]:
        name = f'comm_engine_mode4_rank{rank}.json'
        d = json.loads((RESULTS / name).read_text())
        assert not d['complete'] and d.get('error')
        digest = hashlib.sha256((RESULTS / 'comm_engine_initial_source.py').read_bytes()).hexdigest()
        assert d['source_sha256'] == digest
        summary['failures_preserved'].append({'file': name, 'complete': False, 'error': d['error'],
            'recorded_cases': len(d['cases']), 'excluded_from_performance_comparison': True})
    summary['decision'] = 'Mode-ranking crossover recurs with reversed launch order and fresh inputs. Proceed only to engine profiling and real overlap feasibility, then default/best-fixed/legal-quota serving baselines; no controller gain or novelty established.'
    (RESULTS / 'comm_engine_screening_summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary['comparison'], indent=2))


if __name__ == '__main__':
    main()

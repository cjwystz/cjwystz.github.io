"""Copied only to this experiment's PYTHONPATH as sitecustomize.py.

Override the TP device domain only. Do not change installed SGLang or global env.
"""
import hashlib
import json
import os
import pathlib
import sys

if 'CJW_TP_HCCL_MODE' in os.environ:
    import torch.distributed as dist
    import torch_npu

    mode = int(os.environ['CJW_TP_HCCL_MODE'])
    assert mode in (0, 4)
    original = dist.new_group

    def new_group(*args, **kwargs):
        desc = kwargs.get('group_desc')
        if kwargs.get('backend') == 'hccl' and desc == 'tp:device':
            opts = kwargs.get('pg_options')
            if opts is None:
                opts = torch_npu._C._distributed_c10d.ProcessGroupHCCL.Options()
            config = dict(opts.hccl_config)
            config['hccl_op_expansion_mode'] = mode
            opts.hccl_config = config
            kwargs['pg_options'] = opts
            print('CJW_TP_MODE ' + json.dumps({'mode': mode, 'rank': dist.get_rank(),
                'group_desc': desc, 'config': config,
                'hook_sha256': hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()}),
                file=sys.stderr, flush=True)
        return original(*args, **kwargs)

    dist.new_group = new_group

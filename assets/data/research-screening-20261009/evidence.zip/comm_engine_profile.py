"""Device-path diagnostic. Profiler times are not performance comparisons."""
import argparse
import datetime
import hashlib
import json
import os
import pathlib
import random
import time

import torch
import torch.distributed as dist
import torch_npu


def main(a):
    rank = int(os.environ['RANK'])
    torch.set_num_threads(2)
    torch.npu.set_device(int(os.environ['LOCAL_RANK']))
    torch.npu.config.allow_internal_format = False
    root = pathlib.Path('/workspace/cjw-research/results')
    stem = f'comm_profile_mode{a.mode}_{a.tag}'
    output_file = root / f'{stem}_rank{rank}.json'
    profile_dir = root / stem / f'rank{rank}'
    assert not output_file.exists() and not profile_dir.exists(), 'Preserve prior evidence'
    report = {'complete': False, 'arguments': vars(a), 'rank': rank,
              'physical_cards': [6, 7], 'source_sha256': hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),
              'started_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'scope': 'Synthetic graph device-path profile, NOT performance results', 'cases': []}
    output_file.write_text(json.dumps(report, indent=2))
    control = None
    try:
        opts = torch_npu._C._distributed_c10d.ProcessGroupHCCL.Options()
        opts.hccl_config = {'hccl_op_expansion_mode': a.mode}
        dist.init_process_group('hccl', pg_options=opts, timeout=datetime.timedelta(seconds=120))
        control = dist.new_group(backend='gloo', timeout=datetime.timedelta(seconds=120))
        compute_stream, comm_stream = torch.npu.Stream(), torch.npu.Stream()
        cube_input = torch.ones((2048, 2048), dtype=torch.bfloat16, device='npu')
        cube_out = torch.empty_like(cube_input)
        vector_input = torch.ones((1024, 4096), dtype=torch.bfloat16, device='npu')
        vector_out = torch.empty_like(vector_input)
        graphs = {}
        for name in ('cube', 'vector'):
            def compute():
                for _ in range(16):
                    if name == 'cube':
                        torch.mm(cube_input, cube_input, out=cube_out)
                    else:
                        torch.softmax(vector_input, dim=-1, out=vector_out)
            with torch.npu.stream(compute_stream):
                for _ in range(3):
                    compute()
            compute_stream.synchronize()
            graph = torch.npu.NPUGraph()
            with torch.npu.graph(graph, stream=compute_stream):
                compute()
            graphs[name] = graph
        source = torch.full((a.kib * 1024 // 2,), rank + 1, dtype=torch.bfloat16, device='npu')
        output = torch.empty_like(source)
        with torch.npu.stream(comm_stream):
            for _ in range(5):
                output.copy_(source)
                dist.all_reduce(output)
        comm_stream.synchronize()
        comm_graph = torch.npu.NPUGraph()
        with torch.npu.graph(comm_graph, stream=comm_stream):
            output.copy_(source)
            dist.all_reduce(output)
        for name in ('none', 'cube', 'vector', 'cube_only', 'vector_only'):
            for _ in range(3):
                if name != 'none':
                    with torch.npu.stream(compute_stream):
                        graphs[name.removesuffix('_only')].replay()
                if not name.endswith('_only'):
                    with torch.npu.stream(comm_stream):
                        comm_graph.replay()
                torch.npu.synchronize()
        order = [(rep, name) for rep in range(3) for name in ('none', 'cube', 'vector', 'cube_only', 'vector_only')]
        random.Random(20261009).shuffle(order)
        config = torch_npu.profiler._ExperimentalConfig(profiler_level=torch_npu.profiler.ProfilerLevel.Level1)
        with torch_npu.profiler.profile(
            activities=[torch_npu.profiler.ProfilerActivity.CPU, torch_npu.profiler.ProfilerActivity.NPU],
            on_trace_ready=torch_npu.profiler.tensorboard_trace_handler(str(profile_dir), worker_name=f'mode{a.mode}_rank{rank}'),
            record_shapes=False, profile_memory=False, with_stack=False, experimental_config=config,
        ) as prof:
            for rep, name in order:
                source.fill_(rank + 1 + rep)
                output.fill_(-1)
                cube_out.fill_(-1)
                vector_out.fill_(-1)
                torch.npu.synchronize()
                dist.barrier(group=control)
                label = f'comm_probe:{a.mode}:{rank}:{rep}:{name}'
                start = time.perf_counter()
                with torch.autograd.profiler.record_function(label):
                    if name != 'none':
                        with torch.npu.stream(compute_stream):
                            graphs[name.removesuffix('_only')].replay()
                    if not name.endswith('_only'):
                        with torch.npu.stream(comm_stream):
                            comm_graph.replay()
                    comm_stream.synchronize()
                    compute_stream.synchronize()
                elapsed = time.perf_counter() - start
                if not name.endswith('_only'):
                    assert output.eq(3 + 2 * rep).all().item()
                if name.startswith('cube'):
                    assert cube_out.eq(2048).all().item()
                if name.startswith('vector'):
                    assert vector_out.eq(1 / 4096).all().item()
                report['cases'].append({'repeat': rep, 'compute': name, 'label': label,
                    'profiled_host_ms': 1000 * elapsed, 'all_output_gates_passed': True})
                prof.step()
        report['profile_files'] = sorted(str(p.relative_to(root)) for p in profile_dir.rglob('*') if p.is_file())
        report['complete'] = True
    except Exception as exc:
        report['error'] = repr(exc)
        raise
    finally:
        if control is not None:
            dist.destroy_process_group(control)
        if dist.is_initialized():
            dist.destroy_process_group()
        report['finished_at_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        output_file.write_text(json.dumps(report, indent=2))


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--mode', type=int, choices=(0, 1, 4), required=True)
    p.add_argument('--kib', type=int, default=16384)
    p.add_argument('--tag', default='level1')
    main(p.parse_args())

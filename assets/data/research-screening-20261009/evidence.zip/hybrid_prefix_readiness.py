"""Own-server lifecycle and full-model cold versus prefix-restored smoke gate.

Readiness diagnostic only: single client, synthetic token IDs, logprobs enabled.
All runs use the same full Qwen3.5 model; no distributed-policy gain is claimed.
"""
import argparse
import hashlib
import json
import os
import pathlib
import random
import signal
import subprocess
import time
import urllib.request

ROOT = pathlib.Path('/workspace/cjw-research')
OUT = ROOT / 'results/hybrid_prefix_readiness.json'
URL = 'http://127.0.0.1:32455'
COMMAND = ['python', '-m', 'sglang.launch_server', '--model-path', str(ROOT / 'models/Qwen3.5-0.8B'),
           '--device', 'npu', '--attention-backend', 'ascend', '--host', '127.0.0.1', '--port', '32455',
           '--mamba-radix-cache-strategy', 'extra_buffer', '--page-size', '128',
           '--mamba-track-interval', '256', '--max-mamba-cache-size', '64',
           '--max-total-tokens', '8192', '--max-running-requests', '8', '--context-length', '4096',
           '--mem-fraction-static', '0.3', '--chunked-prefill-size', '1024', '--cuda-graph-max-bs-decode', '8']


def http(path, payload=None):
    body = None if payload is None else json.dumps(payload).encode()
    req = urllib.request.Request(URL + path, data=body, headers={'Content-Type': 'application/json'})
    return urllib.request.urlopen(req, timeout=120)


def generate(ids, count):
    payload = {'input_ids': ids, 'sampling_params': {'temperature': 0, 'max_new_tokens': count, 'ignore_eos': True},
               'stream': True, 'return_logprob': True, 'logprob_start_len': len(ids) - 1}
    start = time.perf_counter()
    events = []
    final = None
    with http('/generate', payload) as response:
        for line in response:
            if line.startswith(b'data:') and line.strip() != b'data: [DONE]':
                final = json.loads(line[5:])
                if 'error' in final:
                    raise RuntimeError(final['error'])
                n = final.get('meta_info', {}).get('completion_tokens', 0)
                if n and (not events or n > events[-1]['tokens']):
                    events.append({'tokens': n, 'time_s': time.perf_counter() - start})
    meta = final['meta_info']
    result = {'ttft_s': events[0]['time_s'], 'elapsed_s': time.perf_counter() - start,
              'events': events, 'text': final['text'], 'meta_info': meta,
              'output_ids': [x[1] for x in meta['output_token_logprobs']]}
    assert meta['prompt_tokens'] == len(ids) and meta['completion_tokens'] == count
    assert len(result['output_ids']) == count
    return result


def main():
    global OUT
    parser = argparse.ArgumentParser()
    parser.add_argument('--prefill-size', type=int, choices=(256, 1024), default=1024)
    args = parser.parse_args()
    COMMAND[COMMAND.index('--chunked-prefill-size') + 1] = str(args.prefill_size)
    stem = 'hybrid_prefix' if args.prefill_size == 1024 else f'hybrid_prefix_prefill{args.prefill_size}'
    OUT = ROOT / f'results/{stem}_readiness.json'
    assert os.environ['ASCEND_RT_VISIBLE_DEVICES'] == '6'
    artifact = json.loads((ROOT / 'results/hybrid_model_download.json').read_text())
    assert artifact['complete']
    report = {'started_unix_s': time.time(), 'command': COMMAND, 'physical_card': 6, 'node': '203',
              'source_sha256': hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),
              'seed': 20261009, 'complete': False, 'cases': [],
              'gates': 'All 32 greedy output IDs equal between cold and restored; exact input/output lengths; cache hits visible in metadata',
              'limits': 'Single-client synthetic-prefix readiness, logprobs enabled; no throughput, task-quality or distributed restore claim'}
    OUT.write_text(json.dumps(report, indent=2))
    # The port must be unused, so a pre-existing service cannot be mistaken for ours.
    import socket
    with socket.socket() as s:
        s.bind(('127.0.0.1', 32455))
    log = (ROOT / f'results/{stem}_server.log').open('w')
    proc = subprocess.Popen(COMMAND, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    report['server_pid_in_container'] = proc.pid
    try:
        deadline = time.monotonic() + 300
        while True:
            if proc.poll() is not None:
                raise RuntimeError(f'server exited {proc.returncode}')
            try:
                with http('/health') as response:
                    if response.status == 200:
                        break
            except Exception:
                pass
            if time.monotonic() > deadline:
                raise TimeoutError('server readiness')
            time.sleep(.5)
        report['server_info'] = json.load(http('/get_server_info'))
        rng = random.Random(20261009)
        prefix = [rng.randrange(1000, 12000) for _ in range(1024)]
        report['prefix_ids'] = prefix
        report['warmup'] = [generate(prefix, 32) for _ in range(2)]
        # Each query shares a different aligned prefix with a 1024-token producer.
        for overlap in (512, 768, 1024):
            suffix = [rng.randrange(12000, 24000) for _ in range(128)]
            ids = prefix[:overlap] + suffix
            for repeat in range(3):
                order = ['cold', 'restored']
                rng.shuffle(order)
                pair = {'overlap': overlap, 'repeat': repeat, 'order': order, 'input_ids': ids, 'runs': {}}
                report['cases'].append(pair)
                for mode in order:
                    with http('/flush_cache') as response:
                        assert response.status == 200
                        response.read()
                    if mode == 'restored':
                        pair['producer'] = generate(prefix, 1)
                    pair['runs'][mode] = generate(ids, 32)
                    OUT.write_text(json.dumps(report, indent=2))
                pair['output_ids_equal'] = pair['runs']['cold']['output_ids'] == pair['runs']['restored']['output_ids']
                print(json.dumps({'overlap': overlap, 'repeat': repeat, 'ids_equal': pair['output_ids_equal'],
                                  'cold_ms': 1000*pair['runs']['cold']['ttft_s'],
                                  'restored_ms': 1000*pair['runs']['restored']['ttft_s'],
                                  'cached_tokens': pair['runs']['restored']['meta_info'].get('cached_tokens')}), flush=True)
                OUT.write_text(json.dumps(report, indent=2))
        report['complete'] = True
        report['all_ids_equal'] = all(c['output_ids_equal'] for c in report['cases'])
    except Exception as exc:
        report['error'] = repr(exc)
        raise
    finally:
        # Only the process group created by this invocation is terminated.
        if proc.poll() is None:
            os.killpg(proc.pid, signal.SIGTERM)
            try:
                proc.wait(timeout=20)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid, signal.SIGKILL)
                proc.wait(timeout=10)
        log.close()
        report['server_returncode'] = proc.returncode
        report['finished_unix_s'] = time.time()
        OUT.write_text(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()

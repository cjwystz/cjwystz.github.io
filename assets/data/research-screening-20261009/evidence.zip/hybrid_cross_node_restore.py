"""Transport a real full-model cache snapshot and resume on another node.

BF16 is a byte carrier for a trusted, checksummed CPU snapshot, not arithmetic.
This is a correctness/readiness fixture, not a production connector benchmark.
"""
import argparse
import datetime
import hashlib
import io
import json
import os
import pathlib
import random
import time

import torch
import torch.distributed as dist
import torch_npu
from transformers import Qwen3_5ForConditionalGeneration

ROOT = pathlib.Path('/workspace/cjw-research')


def run(a):
    torch.set_num_threads(2)
    torch.npu.set_device(0)
    torch.npu.config.allow_internal_format = False
    report = {'complete': False, 'rank': a.rank, 'arguments': vars(a),
              'source_sha256': hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),
              'environment': {k: os.environ.get(k) for k in ('ASCEND_RT_VISIBLE_DEVICES', 'HCCL_SOCKET_IFNAME',
                             'GLOO_SOCKET_IFNAME', 'HCCL_NPU_SOCKET_PORT_RANGE', 'HCCL_HOST_SOCKET_PORT_RANGE')},
              'limits': 'One full-model HF eager prefix256/suffix64; trusted Python cache serialization; includes CPU staging; no production connector or service-performance gain'}
    out = ROOT / f'results/hybrid_cross_restore_rank{a.rank}.json'
    initialized = False
    control = None
    try:
        assert os.environ['ASCEND_RT_VISIBLE_DEVICES'] == '7'
        assert json.loads((ROOT / 'results/hybrid_model_download.json').read_text())['complete']
        with torch.inference_mode():
            model = Qwen3_5ForConditionalGeneration.from_pretrained(
                ROOT / 'models/Qwen3.5-0.8B', dtype=torch.bfloat16,
                attn_implementation='eager', local_files_only=True).eval().to('npu')
            rng = random.Random(20261009)
            prefix = torch.tensor([[rng.randrange(1000,12000) for _ in range(256)]],device='npu')
            suffix = torch.tensor([[rng.randrange(12000,24000) for _ in range(64)]],device='npu')

            def continuation(cache):
                logits, ids = [], []
                result = model(input_ids=suffix, past_key_values=cache, use_cache=True, logits_to_keep=1)
                for step in range(8):
                    current = result.logits[:, -1].float()
                    token = current.argmax(-1).reshape(1,1)
                    ids.append(token.item())
                    logits.append(current.cpu())
                    if step < 7:
                        result = model(input_ids=token, past_key_values=result.past_key_values,
                                       use_cache=True, logits_to_keep=1)
                return ids, torch.stack(logits)

            # Receiver makes a local full-recompute reference before restoring the remote snapshot.
            initial = model(input_ids=prefix, use_cache=True, logits_to_keep=1)
            cache = initial.past_key_values
            fields = [(i,n,v) for i,l in enumerate(cache.layers) for n,v in vars(l).items() if isinstance(v,torch.Tensor)]
            report['tensor_bytes'] = sum(v.numel()*v.element_size() for _,_,v in fields)
            payload = None
            if a.rank == 0:
                for i,n,v in fields:
                    setattr(cache.layers[i],n,v.cpu())
                buffer = io.BytesIO()
                torch.save(cache,buffer)
                payload = buffer.getvalue()
                descriptor = {'length':len(payload),'sha256':hashlib.sha256(payload).hexdigest()}
            else:
                reference_ids, reference_logits = continuation(cache)
                descriptor = None
            torch.npu.synchronize()
            dist.init_process_group('hccl', init_method=f'tcp://10.0.2.203:{a.port}', rank=a.rank,
                                    world_size=2, timeout=datetime.timedelta(seconds=180))
            initialized = True
            control = dist.new_group(backend='gloo', timeout=datetime.timedelta(seconds=180))
            objects = [descriptor]
            dist.broadcast_object_list(objects,src=0,group=control)
            descriptor = objects[0]
            report['payload'] = descriptor
            count = (descriptor['length']+1)//2
            if a.rank == 0:
                padded = payload + b'\0'*(2*count-len(payload))
                tensor = torch.frombuffer(bytearray(padded),dtype=torch.uint8).view(torch.bfloat16).to('npu')
            else:
                tensor = torch.empty(count,dtype=torch.bfloat16,device='npu')
            # Create the HCCL peer path before measuring the real snapshot transfer.
            warm = torch.ones(1,device='npu')
            dist.all_reduce(warm)
            torch.npu.synchronize()
            dist.barrier(group=control)
            start = time.perf_counter()
            work = dist.isend(tensor,dst=1) if a.rank == 0 else dist.irecv(tensor,src=0)
            work.wait()
            torch.npu.synchronize()
            report['hccl_completion_s'] = time.perf_counter()-start
            if a.rank == 1:
                start = time.perf_counter()
                received = tensor.cpu().view(torch.uint8).numpy().tobytes()[:descriptor['length']]
                report['payload_sha256_exact'] = hashlib.sha256(received).hexdigest() == descriptor['sha256']
                assert report['payload_sha256_exact']
                restored = torch.load(io.BytesIO(received),weights_only=False,map_location='cpu')
                restored_fields = [(i,n,v) for i,l in enumerate(restored.layers) for n,v in vars(l).items() if isinstance(v,torch.Tensor)]
                for i,n,v in restored_fields:
                    setattr(restored.layers[i],n,v.to('npu'))
                torch.npu.synchronize()
                report['cpu_deserialize_h2d_s'] = time.perf_counter()-start
                restored_ids, actual_logits = continuation(restored)
                report['reference_ids'] = reference_ids
                report['restored_ids'] = restored_ids
                report['greedy_ids_exact'] = reference_ids == restored_ids
                report['relative_rmse_by_step'] = [((x-y).square().mean()/y.square().mean()).sqrt().item()
                                                   for x,y in zip(actual_logits,reference_logits)]
                report['all_gates_passed'] = report['greedy_ids_exact'] and max(report['relative_rmse_by_step']) <= 1e-6
                assert report['all_gates_passed']
            dist.barrier(group=control)
            report['complete'] = True
    except Exception as exc:
        report['error'] = repr(exc)
        raise
    finally:
        if control is not None:
            dist.destroy_process_group(control)
        if initialized:
            dist.destroy_process_group()
        out.write_text(json.dumps(report,indent=2))
        print(json.dumps(report),flush=True)


if __name__ == '__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--rank',type=int,choices=(0,1),required=True)
    p.add_argument('--port',type=int,default=32456)
    run(p.parse_args())
